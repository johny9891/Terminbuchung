require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const twilio = require('twilio');
const nodemailer = require('nodemailer');
const path = require('path');

const app = express();
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

const client = twilio(process.env.TWILIO_SID, process.env.TWILIO_AUTH);

app.post('/api/book', async (req, res) => {
  const { name, phone, email, datetime } = req.body;
  const message = `Neuer Termin: ${name}, ${phone}, ${email}, ${datetime}`;

  try {
    await client.messages.create({
      body: message,
      from: process.env.TWILIO_PHONE,
      to: '015731320446'
    });

    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: process.env.MAIL_USER,
        pass: process.env.MAIL_PASS
      }
    });

    await transporter.sendMail({
      from: \`"Webseite" <\${process.env.MAIL_USER}>\`,
      to: process.env.MAIL_USER,
      subject: "Neuer Termin",
      text: message
    });

    res.status(200).send({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).send({ error: 'Serverfehler' });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(\`Server läuft auf Port \${PORT}\`));

document.getElementById('bookingForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const formData = {
    name: document.getElementById('name').value,
    phone: document.getElementById('phone').value,
    email: document.getElementById('email').value,
    datetime: document.getElementById('datetime').value
  };
  const response = await fetch('/api/book', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(formData)
  });
  if (response.ok) {
    document.getElementById('confirmation').classList.remove('hidden');
    document.getElementById('bookingForm').reset();
  } else {
    alert('Fehler beim Senden des Formulars.');
  }
});
